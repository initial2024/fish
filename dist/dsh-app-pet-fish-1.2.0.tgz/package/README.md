# dsh-app-pet 🐾

把 **DSH Android 的悬浮球**变成 [dsh-pet](https://github.com/PC2005-cloud/dsh-pet) 风格的**桌面宠物**。

装上、重启，悬浮球自己就活了：待机随机小动作、点一下有回应、拖起来能甩出去弹墙、你干活时它跟着换姿势并冒一句话。

> 24 段手绘风**透明 webm** 动画随包分发（约 11 MB），不需要额外下载任何素材。

---

## 效果

| 你会看到 | 什么时候 |
|---|---|
| 待机呼吸、哼歌、玩魔方、写代码、打盹、吃白饭、伸懒腰、打哈欠、偷吃零食、摇扇纳凉 | 闲着的时候，**每段播完随机抽下一段** |
| 东张西望（并翻个朝向） | 随机链抽到「转向」 |
| 螃蟹走路、原地漂浮踏步（真的会走一段） | 随机链抽到「移动」，或每 30 秒自己溜达 |
| 开心跃动 / 害羞惊讶 / 傲娇生气 / 元气挥手 | **点一下**它 |
| 被拎起来悬空挣扎 | **按住拖动**它 |
| 甩出去沿抛物线飞、撞屏幕边反弹、落地摩擦停下 | **用力甩**它 |
| 思考冒泡 / 忙碌点按 / 清点归档 / 原地踱步张望 / 雀跃庆祝 / 垂头叹气冒汗 | 你**发消息、跑工具、等确认、完成、出错**时自动切 |
| 头顶一句话（如「正在处理任务呢」「这一轮搞定啦，真棒！」） | 状态切换时，4 秒后收起 |

---

## 安装

```sh
dsh plugin --profile web add dsh-app-pet
```

装完**重启 App**。宠物出现在悬浮球上，首次启动会自己下发配置（约 5 秒后开始，最多重试 3 次）。

> 悬浮球默认只在 App 退到后台时可见（`state: "auto"`）。想让它在前台也钉着，
> 让 AI 调 `bubble` 工具设 `state: "collapsed"`，或在 App 的悬浮球设置里改。

### 手动安装（不走插件管理器）

把本包解到 `$DSH_HOME/deskpet/dsh-app-pet/`，然后在
`$DSH_HOME/profiles/web/cordis.patch.yml` 末尾追加：

```yaml
- insert:
    - id: dsh-app-pet
      name: 'file:///data/user/0/com.dsh.android/files/home/.dsh/deskpet/dsh-app-pet/lib/index.js'
```

（把 `web` 换成你实际在用的 profile 名；绝对路径按你的设备改。）

---

## 它到底做了什么

本插件**不碰原生代码**，只做一件事：把一份桌宠配置通过**文件信箱**
（`$DSH_HOME/bubble-cmd.json` → 原生 250 ms 轮询 → `bubble-result.json` 回执）
下发给悬浮球。配置是声明式的，在 [`presets/pet.json`](presets/pet.json)：

- **24 个动作** → `assets/webm/*.webm`（透明 VP9-alpha）
- **5 个动作池** → `idle`（10 段随机小动作）、`turn`、`drag`、`click`（4 段点击回应）、`move`（2 段走路）
- **权重** → `idle: 10`、`turn: 2`
- **七档运行状态映射** → `thinking / working / waiting / error / result / success` 各一段专用动画
- **七档状态文案** → 每档多句，切换时随机抽一句

改预设 → 重启即生效（指纹变了才重新下发，见下）。

### 为什么要做成插件

1. **素材要跟着走** —— 24 段 webm 放在包里，换台机器不会断链。
2. **要能分享** —— 别人装一个包就得到同样效果，不用知道动作名怎么起、池怎么分。
3. **要能重放** —— 配置是文件，不依赖"上次 AI 记不记得配过什么"。

### 只下发一次（指纹机制）

用户在配置之后用 `bubble` 工具把宠物改成别的样子，重启**不该**把它按回去。
所以插件记一个**预设指纹**（预设 JSON 的 sha256 + 每个素材的字节数，前 16 位）：

- 指纹一致 → 跳过下发，一个字都不发；
- 指纹不一致 → 重新下发。

这样"改了预设却忘了改版本号"这种**静默失效**不会发生。想强制重新套用：
让 AI 调 `deskpet` 工具的 `apply`。

---

## AI 工具：`deskpet`

本插件注册一个 `deskpet` 工具，供 AI 在会话里操作：

| action | 作用 |
|---|---|
| `apply` | 重新下发预设（可传 `preset` 换一份预设） |
| `status` | 报告包路径、可用预设、当前/已应用指纹、素材段数、命令信箱 |
| `list` | 列出 24 段素材（动作名、体积、来源动画名） |

它和内置的 `bubble` 工具**共用同一个信箱但 id 空间错开**（本插件从 100 万起），
所以两者可以在同一会话里混用，不会串回执。

---

## 配置参考

预设字段（完整示例见 [`presets/pet.json`](presets/pet.json)）：

```jsonc
{
  "assets": "assets/webm",        // 素材目录（相对包根）
  "actions": { "idle-main": "idle-main", ... },  // 动作名 → 素材文件名（不含 .webm）
  "sources": { "idle-main": "待机呼吸休闲", ... }, // 仅供 list 显示来源，不参与下发
  "pools": {
    "idle":  ["idle-main", "hum", ...],  // 随机待机链
    "turn":  ["turn"],                   // 转向（播完翻朝向）
    "drag":  ["drag"],                   // 被拖拽时的姿势
    "click": ["click-a", ...],           // 点一下的回应
    "move":  ["walk-a", "walk-b"]        // 走路
  },
  "poolWeights": { "idle": 10, "turn": 2 },
  "actionMap": {
    "idle": "idle-main", "thinking": "think", "working": "work",
    "waiting": "wait", "error": "error", "result": "result", "success": "success"
  },
  "moveParams": { "walk-a": { "minDp": 50, "maxDp": 130 } },
  "appearance": { "shape": "square", "size": 96, "bgOpacity": 0, "avatar": "none" },
  "move": { "enabled": true, "intervalSec": 30, "minDp": 40, "maxDp": 120 },
  "statusAutoHideMs": 4000,
  "workStatusTexts": [ ["待机文案…"], ["思考文案…"], ... ]
}
```

⚠️ 动作名只能用 `a-z 0-9 - _`（最多 24 字符）——**中文会变成目录名，被原生拒绝**。
所以素材文件名用了英文，中文原名记在 `sources` 里。

### 想换素材

把新 webm 放进 `assets/webm/`，改 `actions` 指向它，重启。素材要求：

- **透明 webm（VP9 + alpha）**，原生直接播；
- 单个 ≤ 6 MB；
- 一次下发的全部动作 base64 合计 ≤ 12 MB（24 段 × 平均 450 KB 远低于此）。

---

## 边界

- **悬浮球必须存在且启用**。它在 App 的悬浮球设置里可以关掉；关掉后配置照样下发成功，
  但你看不到宠物（这不是本插件的失败）。
- **首次下发有约 5 秒延迟**：原生悬浮球可能比引擎晚起来。失败会退避重试 3 次，
  仍失败就**不标记已应用**，下次启动再试 —— 绝不会"一次失败就永远没有宠物"。
- **配置存在 App 里，不在插件里**。卸载插件后宠物照常活着（配置已落盘）；
  想彻底清掉，用 `bubble` 工具把 `actions` / `pools` 清空。
- 动画**流畅度与切帧**依赖原生播放器，本插件只负责把素材和调度规则送过去。

---

## 素材来源与许可

本包 `assets/webm/` 下的 24 段动画取自 **[dsh-pet](https://github.com/PC2005-cloud/dsh-pet)**
（作者 PC2005-cloud，MIT License），仅做了**重命名**（中文名 → 英文动作名），
未修改内容。原始中文名记录在 `presets/pet.json` 的 `sources` 字段里。

```
MIT License

Copyright (c) 2026 PC2005-cloud
```

本插件自身同样以 MIT License 发布。
